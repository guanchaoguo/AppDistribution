define({
  "name": "app热点分发后台管理系统API接口文档",
  "version": "1.0.0",
  "description": "app热点分发后台管理系统API与前端接口数据通讯",
  "title": "app热点分发后台管理系统API接口文档",
  "url": "http://127.0.0.1:8080",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-01-02T09:23:17.082Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
